#!/usr/bin/env python3
"""Conservatively force all AmigaDOS HUNK_HEADER allocations into CHIP RAM.
HUNK_HEADER size-table placement governs LoadSeg memory selection.
Rejects resident-name tables (nonzero) and exotic extended size tables.
Post-LoadSeg native installer also verifies TypeOfMem(...)=MEMF_CHIP.
"""
import sys, struct, pathlib
MAGIC = 0x3F3
CHIP = 0x40000000
MASK = 0xC0000000

def patch(data):
    data = bytearray(data)
    if len(data) < 24 or len(data) % 4:
        raise ValueError('invalid HUNK size')
    def rd(pos):
        if pos+4 > len(data):
            raise ValueError('truncated HUNK')
        return struct.unpack_from('>I', data, pos)[0]
    if rd(0) != MAGIC or rd(4) != 0:
        raise ValueError('only standard HUNK_HEADER with no resident names is accepted')
    count, first, last = rd(8), rd(12), rd(16)
    if not 0 < count <= 12 or last-first+1 != count:
        raise ValueError('bad HUNK size table')
    for i in range(count):
        offset = 20+i*4
        v = rd(offset)
        if v & MASK == MASK:
            raise ValueError('unsupported extended memory attributes')
        struct.pack_into('>I', data, offset, (v & ~MASK) | CHIP)
    return bytes(data), count

def main():
    if len(sys.argv) != 3:
        sys.exit('usage: hunk_force_chip.py INPUT OUTPUT')
    src = pathlib.Path(sys.argv[1]); dest = pathlib.Path(sys.argv[2]);
    blob, count = patch(src.read_bytes());dest.write_bytes(blob)
    print(f'Forced CHIP memory for {count} HUNK_HEADER allocations: {dest}')
if __name__ == '__main__': main()
