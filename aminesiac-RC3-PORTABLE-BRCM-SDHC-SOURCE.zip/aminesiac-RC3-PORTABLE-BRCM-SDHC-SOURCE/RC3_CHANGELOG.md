# aminesiac RC3 — minimal-change engineering record

## Goal

Remove a build-specific requirement on `brcm-sdhc.device` without touching the RC2 COW algorithm, I/O command policy, partition translation, resident entry assembly, or timing of the early Exec gates.

## Removed build pinning

| RC2 check | RC3 replacement |
|---|---|
| `lib_Version == 1 && lib_Revision == 9` | Diagnostic only; no version rejection |
| `lib_IdString` contains `git:8cd62a7,dirty` | Not required or interpreted |
| Original BeginIO pointer `0x4000ffee` | Original vector decoded at runtime and compared with `SetFunction` return |
| Private pointers at offsets `0x110`/`0x114` | Not accessed; ignored entirely |
| Specific private Read/Write target addresses | Removed |
| Resident only checks hard-coded original BeginIO | Confirms both installed vectors and both original callbacks |

The `-30` and `-36` entry offsets are Exec **standard LVOs**, not internal driver offsets. RC3 does require a standard JMP absolute-long vector layout; variants with other vector encodings will fail the probe. This is a deliberate compatibility boundary rather than silently accepting an unknown ABI.

## Safety behavior

The unmodified policy intercepts only known READ/WRITE/UPDATE/CLEAR/FLUSH operations; non-data safe controls use the native driver; unrecognized, potentially writing commands receive an error. If the device has an unexpected but patchable vector layout at a warm reset, the kernel attempts to keep its own gate in front of it and marks the session failed. This is **not** a hard guarantee against a write path operating outside the Exec vectors.

## Regression surface

| Area | RC3 modification |
|---|---|
| `src/cow.h`, `src/alias_map.h` | None |
| `src/rc2_command_policy.h`, `src/entry.S` | None |
| FAST+KICK allocator, COW persistent struct layout | Same fields, new protocol identifiers |
| Worker queue, I/O completion and abort path | Unchanged |
| `rc2_patch()` | Dynamic vector capture + pre/post checks |
| `rc2_driver_ok()` | Dynamic postpatch checks rather than known binary target |
| Installer + CLI | Dynamic preflight, new read-only `PROBE`, RC3 names |
| Tests | New driver-compat unit test and RC3 invariants |

The predecessor was **a single RC3 source candidate** with an independent read-only probe; there are no gratuitous intermediate firmware versions to install.

## aminesiac rebrand

See `REBRAND_NOTES.md`. The original RC3 candidate has since been hardware-validated on the tested brcm-sdhc 1.9 setup; the renamed `aminesiac` artifacts are untested on Amiga until rebuilt and checked.
