import unittest
import sys, pathlib, struct
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]/'tools'))
from hunk_force_chip import patch

class HunkTests(unittest.TestCase):
    def test_standard_header(self):
        words=[0x3f3,0,2,0,1,0x10,0x80000020,0x3e9,0]
        out,n=patch(struct.pack('>'+('I'*len(words)),*words))
        fields=struct.unpack('>'+('I'*len(words)),out)
        self.assertEqual((n,fields[5],fields[6]),(2,0x40000010,0x40000020))
    def test_unknown_extended_rejected(self):
        words=[0x3f3,0,1,0,0,0xc0000010]
        with self.assertRaises(ValueError):patch(struct.pack('>6I',*words))
    def test_wrong_signature_rejected(self):
        with self.assertRaises(ValueError):patch(bytes(24))
    def test_long_count_rejected(self):
        w=[0x3f3,0,13,0,12]+[1]*13
        with self.assertRaises(ValueError):patch(struct.pack('>18I',*w))
if __name__=='__main__':unittest.main()
