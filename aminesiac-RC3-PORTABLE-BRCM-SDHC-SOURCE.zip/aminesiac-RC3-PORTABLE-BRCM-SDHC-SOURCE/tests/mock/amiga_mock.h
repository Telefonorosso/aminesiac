#ifndef RC2_MOCK_AMIGA
#define RC2_MOCK_AMIGA
#include <stddef.h>
#include <stdint.h>
typedef uint32_t ULONG;
typedef int32_t LONG;
typedef uint16_t UWORD;
typedef unsigned char UBYTE;
typedef signed char BYTE;
typedef void *APTR;
typedef char *STRPTR;
typedef uint32_t BPTR;
#define BADDR(x) ((void*)(uintptr_t)((x)<<2))
#define MEMF_CHIP 2
#define MEMF_FAST 4
#define MEMF_KICK 1024
#define MEMF_PUBLIC 1
#define MEMF_CLEAR 65536
#define RTC_MATCHWORD 0x4afc
#define RTF_COLDSTART 1
#define NT_UNKNOWN 0
#define NT_DEVICE 3
#define NT_MSGPORT 4
#define NT_MESSAGE 5
#define NT_TASK 1
#define NT_KICKMEM 0x15
#define PA_SIGNAL 0
#define IOF_QUICK 1
/* Actual devices/trackdisk.h values, CMD_NONSTD=9. */
#define TD_MOTOR 9
#define TD_REMOVE 12
#define TD_CHANGENUM 13
#define TD_CHANGESTATE 14
#define TD_PROTSTATUS 15
#define TD_GETDRIVETYPE 18
#define TD_GETNUMTRACKS 19
#define TD_ADDCHANGEINT 20
#define TD_REMCHANGEINT 21
#define TD_GETGEOMETRY 22
#define CMD_READ 2
#define CMD_WRITE 3
#define CMD_UPDATE 4
#define CMD_CLEAR 5
#define CMD_FLUSH 8
struct Node {struct Node *ln_Succ,*ln_Pred;UBYTE ln_Type;BYTE ln_Pri;STRPTR ln_Name;};
struct List {struct Node *lh_Head,*lh_Tail,*lh_TailPred;UBYTE lh_Type,lh_Pad;};
struct Library {struct Node lib_Node;UBYTE lib_Flags,lib_pad;UWORD lib_NegSize,lib_PosSize,lib_Version,lib_Revision;STRPTR lib_IdString;ULONG lib_Sum;UWORD lib_OpenCnt;};
struct Device {struct Library dd_Library;};
struct Unit {struct MsgPort *mp;};
struct Task {struct Node tc_Node;UBYTE tc_Flags,tc_State;BYTE tc_IDNestCnt,tc_TDNestCnt;ULONG tc_SigAlloc;APTR tc_SPReg,tc_SPLower,tc_SPUpper;struct List tc_MemEntry;};
struct Message {struct Node mn_Node;struct MsgPort *mn_ReplyPort;UWORD mn_Length;};
struct MsgPort {struct Node mp_Node;UBYTE mp_Flags,mp_SigBit;struct Task *mp_SigTask;struct List mp_MsgList;};
struct IORequest {struct Message io_Message;struct Device *io_Device;struct Unit *io_Unit;UWORD io_Command;UBYTE io_Flags;BYTE io_Error;};
struct IOStdReq {struct Message io_Message;struct Device *io_Device;struct Unit *io_Unit;UWORD io_Command;UBYTE io_Flags;BYTE io_Error;ULONG io_Actual,io_Length;APTR io_Data;ULONG io_Offset;};
struct DriveGeometry {ULONG dg_SectorSize,dg_TotalSectors;};
struct Resident {UWORD rt_MatchWord;struct Resident*rt_MatchTag;APTR rt_EndSkip;UBYTE rt_Flags,rt_Version,rt_Type;BYTE rt_Pri;STRPTR rt_Name,rt_IdString;APTR rt_Init;};
struct MemEntry {union{APTR meu_Addr;}me_Un;ULONG me_Length;};
struct MemList {struct Node ml_Node;UWORD ml_NumEntries;struct MemEntry ml_ME[1];};
struct ExecBase {struct Library LibNode;struct List DeviceList,LibList;APTR KickMemPtr,KickTagPtr,KickCheckSum;};
APTR AllocMem(ULONG,ULONG);void FreeMem(APTR,ULONG);ULONG TypeOfMem(APTR);
void Forbid(void);void Permit(void);void Disable(void);void Enable(void);
void CacheClearU(void);void SumLibrary(struct Library*);
APTR SetFunction(struct Library*,LONG,APTR);
APTR AddTask(struct Task*,APTR,APTR);struct Task*FindTask(STRPTR);
ULONG Wait(ULONG);void ReplyMsg(struct Message*);
void PutMsg(struct MsgPort*,struct Message*);struct Message*GetMsg(struct MsgPort*);
LONG OpenDevice(STRPTR,ULONG,struct IORequest*,ULONG);
void CloseDevice(struct IORequest*);LONG DoIO(struct IORequest*);
struct MsgPort*CreateMsgPort(void);void DeleteMsgPort(struct MsgPort*);
struct IORequest*CreateIORequest(struct MsgPort*,ULONG);
void DeleteIORequest(struct IORequest*);void *FindResident(STRPTR);
ULONG SumKickData(void);APTR InitResident(struct Resident*,ULONG);
BPTR LoadSeg(STRPTR);void UnLoadSeg(BPTR);
#endif
