#include "amiga_mock.h"
