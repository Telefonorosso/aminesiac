"""Static invariants only: do NOT represent a runtime Amiga hardware test."""
from pathlib import Path
import unittest
BASE = Path(__file__).resolve().parents[1]
KERNEL = (BASE/'src/rc2_kernel.c').read_text()
POLICY = (BASE/'src/rc2_command_policy.h').read_text()
ASM = (BASE/'src/entry.S').read_text()
INSTALL = (BASE/'src/aminesiac.c').read_text()
PROTO = (BASE/'src/rc2_protocol.h').read_text()
class GateInvariants(unittest.TestCase):
    def test_registration_before_first_open(self):
        self.assertIn('RC2_ADD_LVO (-432L)',KERNEL)
        self.assertIn('rc2_previous_add=SetFunction',KERNEL)
        self.assertIn('void rc2_add_observe(struct Device*d)',KERNEL)
        self.assertIn('rc2_patch(d);',KERNEL)
        self.assertIn('_rc2_add_entry:',ASM)
        self.assertIn('move.l 36(sp),-(sp)',ASM)
    def test_unknown_units_cannot_read_write_passthrough(self):
        unknown=KERNEL.split('int rc2_dispatch(')[1].split('int rc2_abort(')[0]
        self.assertIn('if(rc2_safe_control(c))return 0;', unknown)
        self.assertIn('return rc2_failfast(r,RC2_BUSY)', unknown)
        self.assertIn('if(!rc2_cow_command(c))', unknown)
        self.assertIn('return rc2_failfast(r,RC2_BUSY)', unknown)
    def test_boot_control_whitelist(self):
        self.assertIn('case TD_ADDCHANGEINT:', POLICY)
        self.assertIn('case TD_REMCHANGEINT:', POLICY)
        self.assertIn('case TD_GETGEOMETRY:', POLICY)
        self.assertIn('case TD_REMOVE:', POLICY)
        self.assertIn('case 0x4000:', POLICY)
        self.assertIn('if(!rc2_cow_command(c))', KERNEL)
    def test_live_gate_health_reporting(self):
        self.assertIn('vector_target((struct Library*)d,RC2_BEGIN_LVO)', INSTALL)
        self.assertIn('vector_target((struct Library*)s,RC2_ADD_LVO)', INSTALL)
        self.assertIn('NOT VERIFIED: DO NOT TRUST',INSTALL)
    def test_portable_driver_checks_installer_and_resident(self):
        compat=(BASE/'src/rc2_driver_compat.h').read_text()
        self.assertIn('rc2_driver_prepatch',INSTALL)
        self.assertIn('rc2_driver_prepatch(d,',KERNEL)
        self.assertIn('rc2_driver_postpatch',KERNEL)
        self.assertIn('before_begin!=rc2_addr(b)',KERNEL)
        self.assertIn('before_abort!=rc2_addr(a)',KERNEL)
        self.assertIn('rc2_audit()',KERNEL)
        self.assertNotIn('RC2_EXPECT_ID',KERNEL)
        self.assertNotIn('RC2_BEGIN_EXPECTED',KERNEL)
        self.assertNotIn('driver_fingerprint',INSTALL)
        self.assertNotIn('lib_Revision==9',compat)
        self.assertIn('lib_NegSize>=36',compat)
    def test_read_only_probe_is_not_an_arming_operation(self):
        probe=INSTALL.split('static int probe(void)')[1].split('static int install(')[0]
        self.assertIn('resident_conflict(sys)',probe)
        self.assertIn('rc2_driver_prepatch',probe)
        self.assertIn('audit(io0,io1',probe)
        self.assertNotIn('SetFunction(',probe)
        self.assertNotIn('InitResident(',probe)
        self.assertNotIn('CMD_WRITE',probe)
    def test_new_version_rejects_old_abi(self):
        self.assertIn('#define RC2_VERSION 5UL',PROTO)
        self.assertIn('#define RC2_MAGIC 0x53445233UL',PROTO)
        self.assertIn('!exp->add_entry||!exp->open_entry',INSTALL)
if __name__=='__main__':unittest.main()
