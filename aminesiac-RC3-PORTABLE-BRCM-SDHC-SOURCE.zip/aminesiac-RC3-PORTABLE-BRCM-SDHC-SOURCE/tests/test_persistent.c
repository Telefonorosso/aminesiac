/* Host-only simulation: persistent COW arena survives a runtime-only reset.
 * This does NOT execute a real Amiga Resident or hook brcm-sdhc.device.
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>
#include "cow.h"
#include "alias_map.h"
#define REQ(c) do {if(!(c)){fprintf(stderr,"FAIL %d: %s\n",__LINE__,#c);exit(1);}}while(0)
int main(void){
    struct rc_cow p={0};
    struct {unsigned generation;struct rc_cow *mapping;void *driver,*worker;} runtime;
    uint8_t src[1024],dst[1024];
    uint32_t i;
    p.capacity=8192;p.buckets=16384;p.disk_sectors=100000;
    p.entries=calloc(p.capacity,sizeof(*p.entries));
    p.slots=calloc(p.buckets,sizeof(*p.slots));
    REQ(p.entries&&p.slots);
    for(i=0;i<sizeof(src);i++)src[i]=(uint8_t)(i*17+9);
    REQ(!rc_write(&p,4096,1024,src));
    REQ(p.used==2&&p.writes==1);
    /* Simulate a chord: NO memset/clear of p, entries or slots. */
    memset(&runtime,0,sizeof(runtime));
    runtime.mapping=&p;runtime.generation=2;
    REQ(rc_all_ram(runtime.mapping,4096,1024));
    memset(dst,0,sizeof(dst));
    REQ(rc_overlay(runtime.mapping,4096,1024,dst));
    REQ(!memcmp(src,dst,sizeof(src)));
    for(i=0;i<sizeof(src);i++)src[i]^=(uint8_t)0x9b;
    REQ(!rc_write(runtime.mapping,4096,1024,src));
    REQ(p.used==2&&p.writes==2);
    memset(&runtime,0,sizeof(runtime));
    runtime.mapping=&p;runtime.generation=3;
    memset(dst,0,sizeof(dst));
    REQ(rc_overlay(runtime.mapping,4096,1024,dst));
    REQ(!memcmp(src,dst,sizeof(src)));
    free(p.slots);free(p.entries);
    puts("PASS host: COW 2 sectors survives 2 simulated runtime resets; rewrite persists");
    return 0;
}
