"""Public naming / safe coexistence checks; no assertion of Amiga runtime success."""
from pathlib import Path
import unittest
ROOT = Path(__file__).resolve().parents[1]
CLI = (ROOT/'src/aminesiac.c').read_text()
PROTO = (ROOT/'src/rc2_protocol.h').read_text()
KERNEL = (ROOT/'src/rc2_kernel.c').read_text()
MAKE = (ROOT/'Makefile').read_text()

class RebrandContracts(unittest.TestCase):
    def test_public_artifact_names(self):
        self.assertIn('all: aminesiac aminesiac.R3Module', MAKE)
        self.assertIn('src/aminesiac.c', MAKE)
        self.assertIn('install(mb,"aminesiac.R3Module")', CLI)
        self.assertIn('Usage: aminesiac PROBE', CLI)
        self.assertIn('Requires aminesiac.R3Module', CLI)
        self.assertIn('"aminesiac.RC3.Kick"', CLI)
        self.assertIn('#define RC2_NAME "aminesiac.RC3"', PROTO)
        self.assertIn('aminesiac.RC3.worker', KERNEL)
        self.assertIn('aminesiac RC3 portable SD / COLDSTART', KERNEL)
        self.assertNotIn('Usage: ShadowSD', CLI)
        self.assertNotIn('ShadowSD RC3 / PORTABLE', CLI)
    def test_safe_previous_resident_rejection(self):
        self.assertIn('FindResident((STRPTR)"ShadowSD.RC2")', CLI)
        self.assertIn('FindResident((STRPTR)"ShadowSD.RC3")', CLI)
        self.assertIn('"ShadowSD.RC2.Kick"', CLI)
        self.assertIn('"ShadowSD.RC3.Kick"', CLI)
        self.assertIn('"aminesiac.RC3.Kick"', CLI)
        self.assertIn('strcmp((const char*)exp->resident->rt_Name,RC2_NAME)',CLI)
    def test_protocol_compatibility_unchanged(self):
        self.assertIn('#define RC2_VERSION 5UL', PROTO)
        self.assertIn('#define RC2_MAGIC 0x53445233UL', PROTO)
        self.assertIn('#define RC2_INSTALL_MAGIC 0x52433348UL',CLI)
        self.assertIn('"brcm-sdhc.device"', PROTO)

if __name__=='__main__': unittest.main()
