/* Host-only simulated 68k Exec vector table (no real driver execution).
 * Every test case uses the same standard device ABI at a different build
 * number or code address. This deliberately makes no assumption about
 * driver version/revision/offsets in the positive acceptance test. */
#include <assert.h>
#include <stdio.h>
#include <string.h>
#include <stdint.h>
#include <exec/types.h>
#include <exec/devices.h>
#define RC2_DEVICE "brcm-sdhc.device"
#include "rc2_driver_compat.h"

static void jump(UBYTE *location,ULONG target){
    location[0]=0x4e;location[1]=0xf9;
    location[2]=(UBYTE)(target>>24);location[3]=(UBYTE)(target>>16);
    location[4]=(UBYTE)(target>>8);location[5]=(UBYTE)target;
}
static void build_device(UBYTE*memory,struct Device **dev,UWORD version,
                         UWORD revision,ULONG begin,ULONG abort){
    struct Library *lib=(struct Library*)(void*)(memory+128);
    *dev=(struct Device*)(void*)lib;
    memset(memory,0,512);
    lib->lib_Node.ln_Name=(STRPTR)RC2_DEVICE;
    lib->lib_NegSize=64;
    lib->lib_PosSize=sizeof(struct Device);
    lib->lib_Version=version;lib->lib_Revision=revision;
    jump((UBYTE*)lib-30,begin);
    jump((UBYTE*)lib-36,abort);
}
int main(void){
    UBYTE memory[512];struct Device*d;
    ULONG b,a;unsigned i;
    const UWORD versions[][2]={{1,6},{1,9},{1,55},{2,0},{9,127}};
    for(i=0;i<sizeof(versions)/sizeof(versions[0]);i++){
        ULONG bp=0x4000ffeeU+(ULONG)i*0x1000U;
        ULONG ap=0x40001110U+(ULONG)i*0x1000U;
        build_device(memory,&d,versions[i][0],versions[i][1],bp,ap);
        assert(rc2_driver_prepatch(d,&b,&a));
        assert(b==bp&&a==ap);
        jump((UBYTE*)d-30,0x0000a83aU);
        jump((UBYTE*)d-36,0x0000a85aU);
        assert(rc2_driver_postpatch(d,b,a,0x0000a83aU,0x0000a85aU));
        assert(!rc2_driver_postpatch(d,b,a,0x0000a83cU,0x0000a85aU));
        assert(!rc2_driver_postpatch(d,b,a,0x0000a83aU,0x0000a85cU));
        assert(!rc2_driver_postpatch(d,0x0000a83aU,a,0x0000a83aU,0x0000a85aU));
    }
    build_device(memory,&d,1,9,0x4000ffeeU,0x40001110U);
    d->dd_Library.lib_Node.ln_Name="impostor.device";
    assert(!rc2_driver_prepatch(d,0,0));
    build_device(memory,&d,1,9,0x4000ffeeU,0x40001110U);
    d->dd_Library.lib_NegSize=30;
    assert(!rc2_driver_prepatch(d,0,0));
    build_device(memory,&d,1,9,0x4000ffeeU,0x40001110U);
    ((UBYTE*)d)[-30]=0x4e;((UBYTE*)d)[-29]=0x75; /* RTS, not JMP */
    assert(!rc2_driver_prepatch(d,0,0));
    build_device(memory,&d,1,9,0x4000ffeeU,0x40001110U);
    jump((UBYTE*)d-30,0x00000001U);
    assert(!rc2_driver_prepatch(d,0,0));
    build_device(memory,&d,1,9,0x4000ffeeU,0x40001110U);
    d->dd_Library.lib_PosSize=0;
    assert(!rc2_driver_prepatch(d,0,0));
    puts("PASS host: release-agnostic Exec vectors, pre/post hook checks, malformed driver rejection");
    return 0;
}
