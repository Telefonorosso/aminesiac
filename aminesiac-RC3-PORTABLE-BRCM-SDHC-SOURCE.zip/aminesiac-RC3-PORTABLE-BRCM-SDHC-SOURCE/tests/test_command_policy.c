#include <assert.h>
#include <stdio.h>
#include <exec/types.h>
#include <exec/io.h>
#include <devices/trackdisk.h>
#include "rc2_command_policy.h"
int main(void){
    const UWORD safe[]={9,12,13,14,15,18,19,20,21,22,0x4000};
    const UWORD unsafe[]={0,1,6,7,10,11,16,17,23,24,25,26,27,28,0xc002,0xc003,0xe000,0xe001,0xe003};
    unsigned i;
    for(i=0;i<sizeof(safe)/sizeof(safe[0]);i++){
        assert(rc2_safe_control(safe[i]));assert(!rc2_cow_command(safe[i]));
    }
    for(i=0;i<sizeof(unsafe)/sizeof(unsafe[0]);i++){
        assert(!rc2_safe_control(unsafe[i]));assert(!rc2_cow_command(unsafe[i]));
    }
    assert(rc2_cow_command(2)&&rc2_cow_command(3)&&
           rc2_cow_command(4)&&rc2_cow_command(5)&&rc2_cow_command(8)&&
           rc2_cow_command(0xc000)&&rc2_cow_command(0xc001));
    assert(!rc2_safe_control(2)&&!rc2_safe_control(3)&&
           !rc2_safe_control(0xc000)&&!rc2_safe_control(0xc001));
    /* TD_GETGEOMETRY is 22; NSCMD_DEVICEQUERY is 0x4000. */
    assert(TD_GETGEOMETRY==22);
    printf("PASS host: boot control pass-through, unsafe requests fail-closed, COW data classified\n");
    return 0;
}
