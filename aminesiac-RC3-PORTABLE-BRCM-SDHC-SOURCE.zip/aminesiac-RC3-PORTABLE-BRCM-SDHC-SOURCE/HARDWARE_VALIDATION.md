# aminesiac RC3 — evidence and validation boundary

## Parent RC3 — hardware validated (user report, 2026-11-02)

The RC3 implementation before rebranding was tested on a physical Amiga with PiStorm/Emu68 and `brcm-sdhc.device` 1.9:

- `PROBE`: PASS, including dynamically discovered `BeginIO=4000ffee`, `AbortIO=4001085c`, geometry/alias checks and read-only sample fingerprint `340b2a53`.
- `ARM MEM=32 I_ACCEPT_RISK`: returned `COLDSTART init result=0`, registered CHIP/FAST/KickMem, worker ready.
- `STATUS` after activation: four gates PASS, `boots=1`, `arms=1`, `faults=0`, RDY2 (`52445932`).
- After a test write on PFS3 SDH1: COW `used=115/65536`, `writes=10`, `reads=21`, `changes=10`, `busy=0`; four gates PASS and faults=0.
- The user explicitly confirmed **all remaining functional tests passed**, including warm reset, full power-off discard, and **PFSDoctor on every volume involved**.

These data support *behavioral* hardware validation of the original RC3 on its tested driver 1.9 setup. The user did not provide a full raw post-reset log with the report; do not invent counters or addresses for that stage. PFSDoctor is filesystem-integrity evidence, not a bit-for-bit test of physical medium immutability.

## Newly named aminesiac — not yet hardware validated

This package changes public names, paths and strings, and adds a protective check to prevent mixing old and new resident modules. It has passed host regression tests only. **It has not yet undergone a real Amiga re-test.** Its successful predecessor does not automatically certify this new binary.

A complete power-cycle is mandatory before switching from the previous named RC3 to this one. Never install on a previously armed system.
