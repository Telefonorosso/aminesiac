# aminesiac RC3 — portable `brcm-sdhc.device` COW

**Source rebrand of the ShadowSD RC3 release-agnostic driver candidate, whose original functionality was subsequently hardware-validated on Amiga/PiStorm/Emu68.** This newly named `aminesiac` executable and resident have **not yet been independently hardware-tested**. This is a source-only package; no Amiga binaries are included.

`aminesiac` implements a volatile microSD copy-on-write overlay via standard Exec device hooks, a COLDSTART resident, and FAST+KICK RAM retention across warm resets. On the hardware configuration that validated the predecessor, test files remained available after Ctrl-Amiga-Amiga and disappeared after fully removing power from both Amiga and Raspberry Pi. PFSDoctor passed on all volumes involved in that validation. These results do not independently prove complete physical write isolation.

## New public names

| Element | Name |
|---|---|
| Project, command | `aminesiac` |
| Main source | `src/aminesiac.c` |
| Standalone HUNK resident | `aminesiac.R3Module` |
| Exec Resident / ROMTag name | `aminesiac.RC3` |
| KickMem registration name | `aminesiac.RC3.Kick` |
| Worker task | `aminesiac.RC3.worker` |

The terminal banner, CLI usage, runtime messages, resident ID and build targets use the new brand. The private C functions/structs prefixed `rc2_*`, compatibility protocol (`SDR3`, version 5), `RC3H` installer magic, disk fingerprinting, data layout, and boot/I/O logic remain those of the validated RC3 source. They are **not public names** and intentionally are not renamed. Historical baseline test logs/checksums are retained verbatim as provenance. Legacy `ShadowSD.RC2` / `ShadowSD.RC3` resident strings remain in the installer exclusively for detecting unsafe co-installation, not for display.

The installer additionally checks that the loaded resident module advertises the matching `aminesiac.RC3` name, preventing accidental pairing with a legacy module renamed on disk. This is a protective pre-install validation only; it does not alter the resident worker, gate behavior, COW algorithm, or on-disk access policy.

## Compatibility boundary

As in RC3, `brcm-sdhc.device` **version and build are diagnostic only**. The driver must expose standard `BeginIO`/`AbortIO` 68k JMP absolute-long Exec vectors, provide the tested sector reads and geometry, and implement the matching 512-byte unit0/unit1 alias mapping with one MBR `0x76` partition. Unknown or potentially write-capable I/O commands are blocked, not passed through. Other controllers, GPT, SCSI-direct writes, other device/vector encodings, and unverified revisions are not supported merely because the project was renamed.

## Cross-build on Linux

Prerequisites: `m68k-amigaos-gcc` and NDK headers (example installation path below).

```bash
cd /root/fmrl
unzip aminesiac-RC3-PORTABLE-BRCM-SDHC-SOURCE.zip
cd aminesiac-RC3-PORTABLE-BRCM-SDHC-SOURCE
make clean
make test-host
make CC=m68k-amigaos-gcc NDK_INCLUDE=/root/ndk-include AMIGA_CRT=-mcrt=nix20 all
ls -lh aminesiac aminesiac.R3Module
sha256sum aminesiac aminesiac.R3Module
```

Transfer the **pair** `aminesiac` and `aminesiac.R3Module` to the same Amiga directory; the installer loads its module from the current directory. Do not mix the old CLI with the new module, or vice versa. The source archive contains no compiled Amiga binaries.

## Safe first test on Amiga

**Only on a full disposable clone of the microSD**, with an independent backup and after completely powering off both Amiga and Pi to clear any earlier active resident:

```text
Stack 65536
aminesiac PROBE
```

`PROBE` runs compatibility and sampled-medium checks without installing resident hooks. A PASS is **not** evidence of physical write isolation.

After reviewing the PROBE output, to activate the memory overlay:

```text
aminesiac ARM MEM=32 I_ACCEPT_RISK
aminesiac STATUS
```

Require COLDSTART init result 0, worker `52445932` (RDY2), faults 0, and all four gates PASS. Stop on a FAIL. There is no DISARM: full power removal is required.

Test a disposable file on `SDH1:`, read it, inspect `aminesiac STATUS`, warm-reset using Ctrl-Amiga-Amiga, and confirm file content, COW state, and gate status without re-running ARM. Finally power off **both** systems completely; after reboot the virtual file must disappear. A PFSDoctor check on all involved volumes is recommended after discard, as in the baseline validation. Do not run repair operations while the overlay is armed.

## Known limitations

- This specific `aminesiac` build is a **newly rebranded binary**, not yet hardware-validated itself, despite the validated predecessor.
- Version-neutral driver checks alone do not prove compatibility with every driver version/build.
- A vector installed by Exec can be replaced during warm reset; monitor gate statuses, especially OpenDevice.
- The system does **not** provide independently verified physical write protection. Early, private, or bypassed driver writes could still reach the medium.
- Full Pi/Amiga power-off discards volatile state; do not use original or irreplaceable storage.

See `REBRAND_NOTES.md`, `HARDWARE_VALIDATION.md`, `TEST_REPORT.md`, `RC3_CHANGELOG.md` and `SOURCE_SHA256.txt`.
