# aminesiac RC3 — host regression and limits

Tests run on the packaged source with `make test-host`:

- Python unit/static-invariant suite: PASS (see `tests/AMINESIAC_HOST_TEST_OUTPUT.txt`).
- C simulated persistent COW state and resets: PASS.
- C command-policy and fail-closed classifications: PASS.
- C driver-vector compatibility tests across simulated versions/addresses: PASS.
- C static syntax verification of installer and resident with mocked NDK: PASS.
- Check that new user-facing names, build targets, legacy-install rejection, and module identity protection are present: PASS.
- Functional module support sources (COW core, alias map, vector ABI, command policy, CHIP HUNK postprocess): byte-for-byte unchanged from RC3.

**Not performed here:** `m68k-amigaos-gcc` cross-build, HUNK/linker check for the renamed module, physical Amiga/PiStorm smoke test of `aminesiac`, real driver versions other than the 1.9 used in the predecessor, or physical sector-hash validation of the SD. The parent RC3 had previously passed a complete user-reported Amiga test suite including PFSDoctor on all volumes involved.
