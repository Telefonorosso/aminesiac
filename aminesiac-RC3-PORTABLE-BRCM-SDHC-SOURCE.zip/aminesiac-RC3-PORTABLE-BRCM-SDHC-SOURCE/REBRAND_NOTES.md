# aminesiac RC3 — controlled rebrand notes

## Intent

Replace the publicly visible project and artifact names without rewriting the validated RC3 driver, COW engine, or boot hooks. Release identifier RC3 remains unchanged.

## Runtime changes (intentionally limited)

- `src/ShadowSD.c` → `src/aminesiac.c`.
- Make targets, installer module filename, public banner, usage and resident ID renamed to `aminesiac`.
- KickMem node, ROMTag name, worker task node renamed.
- CLI refuses a mismatch between the resident module's `rt_Name` and `aminesiac.RC3` **before registration**, preventing mistakenly renamed old modules from being loaded.
- Detection of both historical `ShadowSD.RC2` and `ShadowSD.RC3` ROMTag/KickMem names is preserved for safe rejection of a warm-session upgrade.

## Deliberately unchanged

- `src/cow.h`, `src/alias_map.h`, `src/rc2_command_policy.h`, `src/rc2_driver_compat.h`, `src/entry.S`, and `tools/hunk_force_chip.py` are byte-for-byte identical to the original RC3 candidate.
- Persistent layout, magic (`SDR3`), protocol version (5), installer magic (`RC3H`), and all `rc2_*` ABI symbol names stay unchanged; an existing in-memory installation is nevertheless blocked by the old/new resident name conflict check.
- Physical READ64, partition mapping, I/O policy, RAM retention and resident hooks retain the same implementation.
- Historical SHA256 and test records are retained as evidence, not rewritten to erase the previous project name.

## Safety and validation

A new build cannot be assumed hardware-validated merely because its predecessor passed. Run `PROBE` on a fresh full power cycle, then `ARM`, status/gates, PFS3 read/write, warm reset and power-off discard, finally filesystem integrity checks. The source-only package provides the build outputs' names but not compiled Amiga executables.
